

frida -l frida-il2cpp-bridge.js -l sy.ts -l PopACMenu.ts "AnimalCompany.exe"