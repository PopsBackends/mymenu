

frida -l frida-il2cpp-bridge.js -l sy.ts -l m4.ts -l da.ts "AnimalCompany.exe"